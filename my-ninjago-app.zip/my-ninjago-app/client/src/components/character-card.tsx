import { Character } from "@shared/schema";

interface CharacterCardProps {
  character: Character;
  onClick: () => void;
}

export default function CharacterCard({ character, onClick }: CharacterCardProps) {
  const getBackgroundColor = () => {
    switch (character.element.toLowerCase()) {
      case 'fire':
        return 'from-kai-red to-red-600 border-kai-red';
      case 'lightning':
        return 'from-jay-blue to-blue-600 border-jay-blue';
      case 'energy':
        return 'from-lloyd-green to-green-600 border-lloyd-green';
      case 'ice':
        return 'from-zane-ice to-blue-300 border-zane-ice';
      case 'earth':
        return 'from-earth-brown to-yellow-600 border-earth-brown';
      case 'water':
        return 'from-cyan-500 to-blue-500 border-cyan-500';
      case 'creation':
        return 'from-golden to-yellow-700 border-golden';
      case 'destruction':
        return 'from-purple-600 to-purple-800 border-purple-600';
      default:
        return 'from-gray-600 to-gray-800 border-gray-600';
    }
  };

  const getElementBadgeColor = () => {
    switch (character.element.toLowerCase()) {
      case 'fire':
        return 'bg-fire-orange text-white';
      case 'lightning':
        return 'bg-lightning-cyan text-game-dark';
      case 'energy':
        return 'bg-golden text-game-dark';
      case 'ice':
        return 'bg-white text-game-dark';
      case 'earth':
        return 'bg-yellow-600 text-white';
      case 'water':
        return 'bg-cyan-600 text-white';
      case 'creation':
        return 'bg-white text-game-dark';
      case 'destruction':
        return 'bg-purple-800 text-white';
      default:
        return 'bg-gray-600 text-white';
    }
  };

  const getTextColor = () => {
    return character.element.toLowerCase() === 'ice' || character.element.toLowerCase() === 'creation' 
      ? 'text-game-dark' 
      : 'text-white';
  };

  return (
    <div
      data-testid={`card-character-${character.id}`}
      className={`card-hover bg-gradient-to-b ${getBackgroundColor()} rounded-xl shadow-pixel-hover border-4 cursor-pointer`}
      onClick={onClick}
    >
      <div className="p-6">
        <img
          src={character.imageUrl}
          alt={`${character.name} - ${character.element} Ninja`}
          className="w-full h-48 object-cover rounded-lg mb-4 border-2 border-white"
          data-testid={`img-character-${character.id}`}
        />
        
        <h3 className={`font-pixel ${getTextColor()} text-lg mb-2`} data-testid={`text-name-${character.id}`}>
          {character.name}
        </h3>
        
        <div className="flex items-center justify-between">
          <span className={`font-cyber text-sm ${getElementBadgeColor()} px-2 py-1 rounded`} data-testid={`text-element-${character.id}`}>
            {character.element.toUpperCase()}
          </span>
          <span className="text-2xl" data-testid={`text-emoji-${character.id}`}>{character.emoji}</span>
        </div>
        
        <p className={`font-cyber text-sm mt-3 ${character.element.toLowerCase() === 'ice' || character.element.toLowerCase() === 'creation' ? 'text-gray-600' : 'text-gray-200'}`} data-testid={`text-description-${character.id}`}>
          Master of {character.element}
        </p>
      </div>
    </div>
  );
}
