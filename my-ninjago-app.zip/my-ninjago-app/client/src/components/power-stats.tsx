export default function PowerStats() {
  const powers = [
    {
      name: 'FIRE',
      emoji: '🔥',
      description: 'Destruction & Passion',
      color: 'kai-red'
    },
    {
      name: 'LIGHTNING',
      emoji: '⚡',
      description: 'Speed & Energy',
      color: 'jay-blue'
    },
    {
      name: 'ICE',
      emoji: '❄️',
      description: 'Control & Precision',
      color: 'zane-ice'
    },
    {
      name: 'EARTH',
      emoji: '🗻',
      description: 'Strength & Stability',
      color: 'earth-brown'
    }
  ];

  return (
    <section className="mb-16">
      <h3 className="font-pixel text-2xl text-golden text-center mb-8 animate-glow" data-testid="text-powers-title">
        ELEMENTAL POWERS
      </h3>
      
      <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
        {powers.map((power) => (
          <div 
            key={power.name}
            className={`text-center p-6 bg-${power.color}/20 border-2 border-${power.color} rounded-xl`}
            data-testid={`card-power-${power.name.toLowerCase()}`}
          >
            <div className="text-4xl mb-2" data-testid={`emoji-power-${power.name.toLowerCase()}`}>
              {power.emoji}
            </div>
            <h4 className={`font-pixel text-${power.color} text-sm`} data-testid={`text-power-name-${power.name.toLowerCase()}`}>
              {power.name}
            </h4>
            <p className="font-cyber text-xs text-gray-300 mt-2" data-testid={`text-power-description-${power.name.toLowerCase()}`}>
              {power.description}
            </p>
          </div>
        ))}
      </div>
    </section>
  );
}
