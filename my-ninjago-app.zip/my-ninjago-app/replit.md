# Overview

This is a full-stack React application showcasing Ninjago characters in a gallery format. The application features a modern UI built with React, TypeScript, and shadcn/ui components, with an Express.js backend providing character data through REST APIs. The application currently displays character information including their elemental powers, weapons, descriptions, and power levels in an interactive gallery with modal views for detailed character information.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React 18 with TypeScript using Vite as the build tool
- **UI Framework**: shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with custom theme variables and gaming-inspired design tokens
- **State Management**: TanStack Query (React Query) for server state management
- **Routing**: Wouter for lightweight client-side routing
- **Build System**: Vite with hot module replacement and development optimizations

## Backend Architecture
- **Framework**: Express.js with TypeScript
- **Data Storage**: In-memory storage implementation with interface for future database integration
- **API Design**: RESTful endpoints serving character data at `/api/characters`
- **Development Setup**: Hot reloading with tsx and custom logging middleware
- **Production Build**: ESBuild for optimized server bundling

## Database Schema
- **ORM**: Drizzle ORM configured for PostgreSQL
- **Schema Definition**: Shared schema between frontend and backend with Zod validation
- **Tables**: 
  - Users table with authentication fields
  - Characters table with gaming attributes (element, weapon, power level, etc.)
- **Migration System**: Drizzle Kit for schema migrations

## Component Architecture
- **Design System**: Comprehensive UI component library with consistent theming
- **Character Display**: Specialized components for character cards, modals, and power statistics
- **Responsive Design**: Mobile-first approach with adaptive layouts
- **Accessibility**: Built on Radix UI primitives ensuring WCAG compliance

## Development Workflow
- **Monorepo Structure**: Shared types and schemas between client and server
- **Type Safety**: End-to-end TypeScript with strict configuration
- **Path Aliases**: Organized imports with @ prefixes for components and utilities
- **Error Handling**: Runtime error overlay for development debugging

# External Dependencies

## UI and Styling
- **shadcn/ui**: Complete component library built on Radix UI
- **Tailwind CSS**: Utility-first CSS framework with custom theme
- **Radix UI**: Headless component primitives for accessibility
- **Lucide React**: Icon library for consistent iconography
- **class-variance-authority**: Type-safe component variants

## Data Management
- **TanStack Query**: Server state management and caching
- **Drizzle ORM**: Type-safe database operations and migrations
- **Neon Database**: Serverless PostgreSQL for production data storage
- **Zod**: Schema validation for type safety

## Development Tools
- **Vite**: Fast build tool and development server
- **TypeScript**: Static type checking and enhanced developer experience
- **ESBuild**: Fast JavaScript bundler for production builds
- **Replit Integration**: Development environment optimizations and error handling